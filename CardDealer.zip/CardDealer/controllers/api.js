var mongoose = require('mongoose'),
	Deck = require('../models/Deck.js');

// send index partial to user
exports.index = function(req, res) {
	res.render('index');
};

// respond with json list of decks in db
exports.list = function(req, res) {
	Deck.find(function (err, decks) {
		// if no decks found, redirect to create page
		if(decks) {
			res.json(decks);
		} else {
			res.redirect('/create'); 
		}
	});

};

// create new deck and send as json
exports.create = function(req, res) {
	var deck = new Deck();
	// fill deck with cards
	deck.generateCards(function(err) {
		if(err) {
			res.json(500, {
				error: 'Could not generate cards.'
			});			
		}

	});
	// shuffle cards
	deck.shuffleCards(function(err) {
		if(err) {
			res.json(500, {
				error: 'Could not shuffle cards.'
			});
		}

	});
	// get percentage of correct order
	deck.getPercent(function(err) {
		if(err) {
			res.json(500, {
				error: 'Could not get percent.'
			});
		}
		
	});
	// save deck object
	deck.save(function(err, doc) {
		if(err) {
			res.json(500, {
				error: 'Could not save deck. '
			});
		}
		// respond with json object of deck created + saved
		res.json(deck);
	});

};

// return one deck by id
exports.item = function(req, res) {
	Deck.findOne({_id: req.params.deckId}, function(err, deck) {
		if(err) {
			console.log(err);
			res.send(err);
		} else {
			res.json(deck);
		}
	});
};