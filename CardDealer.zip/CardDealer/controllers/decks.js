// page routes
exports.create = function (req, res) {
	res.render('create');
}
exports.deck = function (req, res) {
	res.render('deck');
};
exports.decks = function (req, res) {
	res.render('decks');
};