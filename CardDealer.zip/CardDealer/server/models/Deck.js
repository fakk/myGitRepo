'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

mongoose.connect('mongodb://localhost/CardDealer');

var DeckSchema = new Schema({
    cards: {
        type: [{
            suit: String,
            number: Number
        }],
        default: []
    },
    percentage_ordered: {
        type: Number,
        default: 100
    }
});
// shuffle card array in deck instance
DeckSchema.methods.shuffleCards = function (cb) {
    var l = this.cards.length, i, temp, swapIndex;
    for (i = 0; i < l; i += 1) {
        temp = this.cards[i];
        swapIndex = Math.floor((Math.random() * 51) + 0);
        this.cards[i] = this.cards[swapIndex];
        this.cards[swapIndex] = temp;
    }
    return cb;
};
// populate card list
DeckSchema.methods.generateCards = function (cb) {

    var tempCards = [], tempSuit, i = 0, switchNumber;
    for (i = 0; i < 52; i += 1) {
        // get 1-4 to determine suit
        switchNumber = Math.ceil((i + 1) / 13);
        if (switchNumber === 1) {
            tempSuit = 'S';
        } else if (switchNumber === 2) {
            tempSuit = 'D';
        } else if (switchNumber === 3) {
            tempSuit = 'H';
        } else {
            tempSuit = 'C';
        }

        tempCards.push({
            suit: tempSuit,
            number: (i + 1) % 13
        });
    }

    this.cards = tempCards;
    return cb;
};

DeckSchema.methods.getPercent = function (cb) {
    var x, y, compareSuit, index, totalPoints = 0;
    for (x = 0; x < 4; x += 1) {
        if (x === 0) {
            compareSuit = 'S';
        } else if (x === 1) {
            compareSuit = 'D';
        } else if (x === 2) {
            compareSuit = 'H';
        } else {
            compareSuit = 'C';
        }

        for (y = 0; y < 13; y += 1) {
            index = (x * 13) + y;
            if (this.cards[index].suit === compareSuit) {
                totalPoints += 1;
            }
            if (this.cards[index].number === index) {
                totalPoints += 1;
            }
        }
    }

    this.percentage_ordered = (totalPoints / 104) * 100;
    return cb;

};
module.exports = mongoose.model('Deck', DeckSchema);