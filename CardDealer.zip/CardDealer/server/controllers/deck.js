var mongoose = require('mongoose'),
	Deck = mongoose.model('Deck');

	exports.index = function(req, res) {
		res.render('index');
	};
	exports.list = function(Deck) {
		return function(req, res) {
			Deck.find(function(err, decks) {
				res.json(decks);
			});
		}
	};
	exports.create = function(req, res) {
		var deck = new Deck();
		// goes through entire creation of deck
		// throws error at each step in creating deck
		deck.generateCards(function(err) {
			if(err) {
				res.json(500, {
					error: 'Could not generate cards.'
				});			
			}

		});
		deck.shuffleCards(function(err) {
			if(err) {
				res.json(500, {
					error: 'Could not shuffle cards.'
				});
			}

		});
		deck.getPercent(function(err) {
			if(err) {
				res.json(500, {
					error: 'Could not get percent.'
				});
			}
			
		});
		deck.save(function(err, doc) {
			if(err) {
				res.json(500, {
					error: 'Could not save deck. ' + deck.cards + deck.percentage_ordered
				});
			}
			// return deck to controller, so it can move to deck view by id
			res.json(doc);

		});

	};
	exports.item = function(req, res) {
		Deck.findOne({ _id : req.params.id }, function(err, deck) {
			if(err) {
				res.render('error, no deck found', {});
			} else {
				res.render('deck', { deck : deck });
			}
		});
	};