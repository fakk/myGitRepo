var decks = require('../controllers/deck');

module.exports = function(app) {
	// frontend routes to handle angular reqs
	app.get('*', function(req, res) {
		res.sendfile('public/index.html');
	});

	app.get('/', decks.index);

	app.get('/decks', decks.list);
	app.get('/create');
	app.get('/deck/:deckId', decks.item);
	
	app.post('/decks', decks.create);

};