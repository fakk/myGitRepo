// var mongoDB = require('MongoDB');
var express = require('express');
var app = express();
var mongoose = require('mongoose');
var Deck = require('./server/models/Deck');
// var http = require('http');
var path = require('path');

var db = require('./config/db');
// var server = http.createServer(app);

var port = process.env.PORT || 3000;
// app.set('port', process.env.VCAP_APP_PORT || 3000);

app.configure(function () {
	app.use(express.static(__dirname + 'public')); 	// set the static files location /public/img will be /img for users
	app.use(express.logger('dev')); 					// log every request to the console
	app.use(express.bodyParser()); 						// have the ability to pull information from html in POST
	app.use(express.methodOverride());
 //    app.use(express.static(__dirname, '/public'));
 //    app.use(express.logger('dev'));
 //    app.use(express.bodyParser());
 //    app.use(express.methodOverride());

	// app.use(function(err, req, res, next) {
	// 	if(!err) return next();
	// 	console.log(err.stack);
	// 	res.json({error: true});
	// });
});

require('./server/routes/routes')(app);

// app.use(express.logger('dev'));
// app.use(express.bodyParser());
// app.use(express.methodOverride());
// app.use(app.router);
// app.use(express.static(path.join(__dirname, 'public')));


app.listen(port);
console.log('Magic happens on port ' + port);			// shoutout to the user
// expose app
exports = module.exports = app;

// server.listen(app.get('port'), function() {
// 	console.log('Express server listening on port ' + app.get('port'));
// });