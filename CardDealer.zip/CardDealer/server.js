var express = require('express'),
	mongoose = require('mongoose'),
	bodyParser = require('body-parser'),
	api = require('./controllers/api'),
	routes = require('./controllers/decks'),
	http = require('http'),
	path = require('path'),
	methodOverride = require('method-override');

var app = module.exports = express();

app.engine('html', require('ejs').renderFile);

app.set('port', process.env.PORT || 3000);
app.use(express.logger('dev'));
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', __dirname + '/public/views/');
app.set('view engine', 'html'); 
app.use(bodyParser.urlencoded({'extended': 'true'}));
app.use(bodyParser.json());
app.use(methodOverride());
app.use(app.router);

var env = process.env.NODE_ENV || 'development';

app.get('/', api.index);
app.get('/api/create', api.create);
app.get('/api/decks', api.list);
app.get('/api/deck/:deckId', api.item);
app.get('/api/new', api.create);

app.get('/deck:id', routes.deck);
app.get('/decks', routes.decks);
app.get('/create', routes.create);


http.createServer(app).listen(app.get('port'), function () {
	console.log('Express port on ' + app.get('port'));
});