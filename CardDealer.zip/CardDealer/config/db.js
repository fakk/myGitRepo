module.exports = {
	url : 'mongodb://localhost/CardDealer'
}