angular.module('dealerApp', [
	'ngRoute',
	'ngResource',
	'dealerApp.controllers'
	]).config(function ($routeProvider, $locationProvider) {
		$routeProvider
			.when('/', {
				templateUrl: '../views/index.html'
			})
			.when('/decks', {
				templateUrl: '../views/decks.html',
				controller: 'DeckListController'
			})
			.when('/deck/:id', {
				templateUrl: '../views/deck.html',
				controller: 'DeckViewController'
			})
			.when('/create', {
				templateUrl: '../views/create.html'
			})
			.otherwise('/', { 
				redirectTo: '/index'
			});

		$locationProvider.html5Mode(true);

});

