angular.module('ListCtrl', []).controller('DeckListController', function($scope, $location, Deck) {
	$scope.tagline = 'Listing decks';
});
angular.module('CreateCtrl', []).controller('DeckCreateController', function($scope, $location, Deck) {
	$scope.tagline = 'Listing decks';
});
angular.module('ItemCtrl', []).controller('DeckItemController', function($scope, $location, Deck) {
	$scope.tagline = 'Displaying single deck';
});
// // Controller for deck list
// function DeckListCtrl ($scope, Deck) {
// 	$scope.decks = Deck.query(); // calls service to query db
// }

// function DeckItemCtrl ($scope, $routeParams, Deck) {
// 	$scope.deck = Deck.get({deckId: $routeParams.deckId});
// }

// function DeckCreateCtrl ($scope, $location, Deck) {
	
// }