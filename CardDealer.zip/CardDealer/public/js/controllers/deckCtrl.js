angular.module('dealerApp.controllers', []).
	controller('DeckViewController', function ($scope, $routeParams, $http) {
		var dealer = this;

		dealer.deck = [ ];
		dealer.deck.percent = 0;

		$http({
			method: 'GET',
			url: '/api/deck/' + $routeParams.id
		}).
		success(function (data, status, headers, config) {
			dealer.deck = data;
			dealer.deck.percent = Math.round(dealer.deck.percentage_ordered * 100) / 100;
		}).
		error(function (data, status, headers, config) {

		});

	}).
	controller('DeckListController', function ($rootScope, $http) {
		var dealer = this;

		dealer.decks = [ ];
		dealer.average = 0;

		$http({
			method: 'GET',
			url: '/api/decks'
		}).
		success(function (data, status, headers, config) {			
			dealer.decks = data;
			var deckCount = dealer.decks.length;
			for (var i = 0; i < deckCount; i++) {
				dealer.average += dealer.decks[i].percentage_ordered;
				dealer.decks[i].percent = Math.round(dealer.decks[i].percentage_ordered * 100) / 100;
				
			}
			dealer.average = calcAverage(dealer.average, deckCount);
			
		}).
		error(function (data, status, headers, config) {
			console.log("error");
		});

		function calcAverage (avg, count) {
			return Math.round((avg / count) * 100) / 100;
		}

	}).
	controller('DeckCreateController', function ($rootScope, $http) {
		var dealer = this;
		dealer.deck = [ ];
		dealer.deck.cards = [ ];
		dealer.hasUpdatedDeck = false;

		for (var i = 0; i < 52; i++) {
			dealer.deck.cards[i] = i;
		}

		dealer.createNew = function () {
			$http({
				method: 'GET',
				url: '/api/new'
			}).
			success(function (data, status, headers, config) {
				dealer.deck = data;
				dealer.hasUpdatedDeck = true;
				dealer.deck.percent = Math.round(dealer.deck.percentage_ordered * 100) / 100;
			}).
			error(function (data, status, headers, config) {	
				console.log('failure');
			});	

		};

	});