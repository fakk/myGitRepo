'use strict';
angular.module('DeckService', ['ngResource']).	
	factory('Deck', function($resource) {
		return $resource('decks/:deckId', {}, {
			// Use this method for getting a list of decks
			query: { method: 'GET', params: { deckId: 'decks' }, isArray: true }
		}); 
	});
	// factory('Deck', ['$http', function ($http) {
 //    return {
 //    // call to GET all decks
 //        get : function () {
 //            return $http.get('/decks');
 //        },
 //        find : function (id) {
 //            return $http.get('/decks/:id');
 //        },
 //        // call to POST a new deck
 //        // no args, since all decks generated uniformally 
 //        create : function() {
 //            return $http.post('/decks');
 //        }
 //    }
 // }])