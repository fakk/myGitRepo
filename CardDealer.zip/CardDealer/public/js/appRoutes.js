// ANGULAR ROUTES
angular.module('appRoutes', [])
	.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {

	$routeProvider
		.when('/decks', {
			templateUrl: '../views/decks.html',
			controller: 'DeckListController'
		})
		.when('/deck/:id', {
			templateUrl: 'views/deck.html',
			controller: 'DeckItemController'
		})
		.when('/create', {
			templateUrl: 'views/create.html',
			controller: 'DeckCreateController'
		})
		.when('/new', {
			templateUrl: 'views/new.html',
			controller: 'DeckCreateController'
		})
		.otherwise('/', { 
			redirectTo: '/decks'
		});

	$locationProvider.html5Mode(true);

}]);